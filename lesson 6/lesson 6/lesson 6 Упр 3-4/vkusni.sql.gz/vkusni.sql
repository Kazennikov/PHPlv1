-- phpMyAdmin SQL Dump
-- version 4.7.3
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Окт 10 2018 г., 21:28
-- Версия сервера: 5.6.37
-- Версия PHP: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `vkusni`
--

-- --------------------------------------------------------

--
-- Структура таблицы `forma`
--

CREATE TABLE `forma` (
  `id` int(11) NOT NULL,
  `name_user` varchar(128) NOT NULL,
  `user_mail` varchar(128) NOT NULL,
  `subj` varchar(128) NOT NULL,
  `text` varchar(512) NOT NULL,
  `ozhenka` int(11) NOT NULL,
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `forma`
--

INSERT INTO `forma` (`id`, `name_user`, `user_mail`, `subj`, `text`, `ozhenka`, `data`) VALUES
(1, 'Сергей', '', 'Обслуживание', 'Хорошее обслуживание', 4, '0000-00-00 00:00:00'),
(2, 'Андрей', '', 'Еда', 'Вкусная еда', 5, '0000-00-00 00:00:00'),
(3, 'Юля', 'ula@bk.com', 'Доставка', 'Доставка опоздала на 1 час', 1, '0000-00-00 00:00:00'),
(4, 'Марина', 'marina@bk.com', 'Тесто', 'Тесто слишком соленое', 3, '0000-00-00 00:00:00'),
(5, 'Виктор', 'marina@bk.com', 'Тесто', 'Тесто слишком соленое', 3, '0000-00-00 00:00:00'),
(6, 'Виктор', 'marina@bk.com', 'Тесто', 'Тесто слишком соленое', 4, '2018-10-09 17:25:25'),
(7, 'Оленька', 'olenka@outl.ru', 'Пончики', 'Хочу еще пончиков!!!!!', 5, '2018-10-10 17:22:24');

-- --------------------------------------------------------

--
-- Структура таблицы `goods`
--

CREATE TABLE `goods` (
  `id` int(11) NOT NULL,
  `naime` varchar(128) NOT NULL,
  `price` varchar(128) NOT NULL,
  `opisanie` varchar(512) NOT NULL,
  `dop_opisani` varchar(512) NOT NULL,
  `img` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `goods`
--

INSERT INTO `goods` (`id`, `naime`, `price`, `opisanie`, `dop_opisani`, `img`) VALUES
(1, 'Круассан', ' 20 руб.', 'Круассаны - французская классическая нежнейшая слоёная выпечка с приятной хрустящей корочкой, которая великолепно подходит к утреннему кофе.', 'Круассан - наверное, самая воздушная булочка!', '../img/kruassan.jpg'),
(2, 'Пончик с сахарной пудрой', '20 руб.', 'Сытный и вкусный завтрак из нежнейшего теста, c глазурью и кондитерской посыпкой. Вы можете побаловать себя сегодня!', 'Вкусный пончик - это лучшее начало дня.', '../img/ponchik.jpg'),
(3, 'Куличи', '20 руб.', 'Куличи - праздничное дрожжевое изделие различной степени сдобности и различное по величине и форме,с изюмом, сверху украшается сахарной пудрой или глазурью..', 'Куличи - праздничный хлеб был круглый и высокий,с украшениями из теста.', '../img/kulich.jpg'),
(4, 'Рулеты', '220 руб.', 'Нежное, вкусное лакомство с различной начинкой. Для приятного чаепития в кругу близких людей.', 'Рулет — одно из любимых лакомств сладкоежек.', '../img/rulet.jpg'),
(5, 'Штрудель', '350руб', 'Десертный штрудель готовится из вытяжного теста с начинкой из фруктов (яблоко), ягод (клубника, вишня, брусника, малина, изюм и т. п.), творога (с ванилью), штрудель с зёрнами мака и корицей или другими компонентами. Сверху сладкий штрудель смазывают растопленным сливочным маслом и посыпают сахарной пудрой.', 'Яблочный штрудель – национальное австрийское блюдо, рулет из тонкого теста с яблочной начинкой', '../img/shtrudel.jpg'),
(6, 'Торты', 'Цена при обращении', 'Что такое торт, знает каждый человек. Это сладкий десерт из выпеченного теста с кремом и различными добавками.Нежное, вкусное лакомство с различной начинкой. Для приятного чаепития в кругу близких людей.', '', '../img/torti.jpg');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `forma`
--
ALTER TABLE `forma`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `goods`
--
ALTER TABLE `goods`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `forma`
--
ALTER TABLE `forma`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT для таблицы `goods`
--
ALTER TABLE `goods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
